/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

/**
 *
 * @author stephanie
 */
public class User {
    public String firstName = "";
    public String lastName = "";
    public String username = "";
    public String password = "";
    public String gender = "";
    public double balance = 0.00;
    public String email = "";
    public String[] items = new String[10];
    public int[] quantities = new int[10];
    public double[] prices = new double[10];
    public double cartTotal = 0.00;
}
